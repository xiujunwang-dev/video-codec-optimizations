#include <arm_neon.h>
int main(void) {
  uint16x8_t v = vdupq_n_u16(17);
  return vgetq_lane_u16(v, 0) != 17;
}
