#include <arm_neon.h>
#include <stdint.h>
#define HIGH_BIT_DEPTH 1
using pixel = uint16_t;
namespace candidate {
template<int N>
static void inline load_u16x4xn(const uint16_t *src, const intptr_t stride,
                                uint16x4_t *dst)
{
    for (int i = 0; i < N; ++i)
    {
        dst[i] = vld1_u16(src);
        src += stride;
    }
}

static inline void sumsubq_s16(int16x8_t *sum, int16x8_t *sub, const int16x8_t a,
                               const int16x8_t b)
{
    *sum = vaddq_s16(a, b);
    *sub = vsubq_s16(a, b);
}

static inline void abssumsubq_s16(int16x8_t *sum, int16x8_t *sub, const int16x8_t a,
                                  const int16x8_t b)
{
    *sum = vabsq_s16(vaddq_s16(a, b));
    *sub = vabdq_s16(a, b);
}

static inline void transpose_s16_s16x2(int16x8_t *t1, int16x8_t *t2, const int16x8_t s1,
                                       const int16x8_t s2)
{
    *t1 = vtrn1q_s16(s1, s2);
    *t2 = vtrn2q_s16(s1, s2);
}

static inline void transpose_s16_s32x2(int16x8_t *t1, int16x8_t *t2, const int16x8_t s1,
                                       const int16x8_t s2)
{
    int32x4_t tmp1 = vreinterpretq_s32_s16(s1);
    int32x4_t tmp2 = vreinterpretq_s32_s16(s2);

    *t1 = vreinterpretq_s16_s32(vtrn1q_s32(tmp1, tmp2));
    *t2 = vreinterpretq_s16_s32(vtrn2q_s32(tmp1, tmp2));
}

static inline void transpose_s16_s64x2(int16x8_t *t1, int16x8_t *t2, const int16x8_t s1,
                                       const int16x8_t s2)
{
    int64x2_t tmp1 = vreinterpretq_s64_s16(s1);
    int64x2_t tmp2 = vreinterpretq_s64_s16(s2);

    *t1 = vreinterpretq_s16_s64(vtrn1q_s64(tmp1, tmp2));
    *t2 = vreinterpretq_s16_s64(vtrn2q_s64(tmp1, tmp2));
}

static inline int calc_energy_4x4(const pixel *source, intptr_t sstride)
{
#if HIGH_BIT_DEPTH
    uint16x4_t s[4];
    load_u16x4xn<4>(source, sstride, s);

    uint16x8_t s01 = vcombine_u16(s[0], s[1]);
    uint16x8_t s23 = vcombine_u16(s[2], s[3]);

    int16x8_t s01_23 = vreinterpretq_s16_u16(vaddq_u16(s01, s23));
    int16x8_t d01_23 = vreinterpretq_s16_u16(vsubq_u16(s01, s23));
#else
    uint8x8_t s[2];
    s[0] = load_u8x4x2(source + 0 * sstride, sstride);
    s[1] = load_u8x4x2(source + 2 * sstride, sstride);

    int16x8_t s01_23 = vreinterpretq_s16_u16(vaddl_u8(s[0], s[1]));
    int16x8_t d01_23 = vreinterpretq_s16_u16(vsubl_u8(s[0], s[1]));
#endif

    // The first line after the vertical hadamard transform contains the sum of coefficients.
    int sum = vaddvq_u16(vreinterpretq_u16_s16(s01_23)) >> 2;

    int16x8_t t0, t1;

    transpose_s16_s64x2(&t0, &t1, s01_23, d01_23);
    sumsubq_s16(&s01_23, &d01_23, t0, t1);

    transpose_s16_s16x2(&t0, &t1, s01_23, d01_23);
    abssumsubq_s16(&s01_23, &d01_23, t0, t1);

    transpose_s16_s32x2(&t0, &t1, s01_23, d01_23);

    int sat = vaddvq_u16(vmaxq_u16(vreinterpretq_u16_s16(t0), vreinterpretq_u16_s16(t1)));

    return sat - sum;
}
}
