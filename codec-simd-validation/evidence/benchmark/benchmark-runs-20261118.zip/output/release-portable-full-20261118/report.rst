Codec SIMD validation run
=========================

Status: validated
Profile: full
Completed at: 2026-11-18T08:36:18.899818+00:00

All cases in this release are historical replays selected after the issues were known.
Validated means that the declared replay expectations held, including expected failures
in historical implementations. It does not mean that every tested implementation is correct.
Observation totals are checks, not independent defects or prospective discoveries.

x265-12bit-psy-reduction
------------------------

Status: validated
Classification: historical_replay
Evidence: cases/x265/result.json

Checks with a reported difference: 32
Checks with an execution or expectation error: 0
* before: x265-before-normal-known-witness-12-1-energy; 1 energy_evaluations
* before: x265-before-normal-known-witness-12-1-cost; 1 input_pairs
* before: x265-before-normal-endpoints-zero-12-1-energy; 1383 energy_evaluations
* before: x265-before-normal-endpoints-zero-12-1-cost; 1383 input_pairs
* before: x265-before-normal-endpoints-near-12-1-energy; 2766 energy_evaluations
* before: x265-before-normal-endpoints-zero-12-17-energy; 1323 energy_evaluations
* before: x265-before-normal-endpoints-zero-12-17-cost; 1323 input_pairs
* before: x265-before-normal-endpoints-near-12-17-energy; 2646 energy_evaluations
* before: x265-before-normal-endpoints-zero-12-20261117-energy; 1336 energy_evaluations
* before: x265-before-normal-endpoints-zero-12-20261117-cost; 1336 input_pairs
* before: x265-before-normal-endpoints-near-12-20261117-energy; 2672 energy_evaluations
* before: x265-before-normal-exhaustive-zero-12-1-energy; 21504 energy_evaluations
* before: x265-before-normal-exhaustive-zero-12-1-cost; 21504 input_pairs
* before: x265-before-normal-exhaustive-complement-12-1-energy; 43008 energy_evaluations
* before: x265-before-normal-exhaustive-complement-12-1-cost; 23296 input_pairs
* before: x265-before-normal-exhaustive-near-12-1-energy; 43008 energy_evaluations
* before: x265-before-sanitized-known-witness-12-1-energy; 1 energy_evaluations
* before: x265-before-sanitized-known-witness-12-1-cost; 1 input_pairs
* before: x265-before-sanitized-endpoints-zero-12-1-energy; 1383 energy_evaluations
* before: x265-before-sanitized-endpoints-zero-12-1-cost; 1383 input_pairs
* before: x265-before-sanitized-endpoints-near-12-1-energy; 2766 energy_evaluations
* before: x265-before-sanitized-endpoints-zero-12-17-energy; 1323 energy_evaluations
* before: x265-before-sanitized-endpoints-zero-12-17-cost; 1323 input_pairs
* before: x265-before-sanitized-endpoints-near-12-17-energy; 2646 energy_evaluations
* before: x265-before-sanitized-endpoints-zero-12-20261117-energy; 1336 energy_evaluations
* before: x265-before-sanitized-endpoints-zero-12-20261117-cost; 1336 input_pairs
* before: x265-before-sanitized-endpoints-near-12-20261117-energy; 2672 energy_evaluations
* before: x265-before-sanitized-exhaustive-zero-12-1-energy; 21504 energy_evaluations
* before: x265-before-sanitized-exhaustive-zero-12-1-cost; 21504 input_pairs
* before: x265-before-sanitized-exhaustive-complement-12-1-energy; 43008 energy_evaluations
* before: x265-before-sanitized-exhaustive-complement-12-1-cost; 23296 input_pairs
* before: x265-before-sanitized-exhaustive-near-12-1-energy; 43008 energy_evaluations

Limits:
* Retrospective replay of a known defect; no prospective discovery claim.
* The production kernel and helpers are extracted without modification; this is not end-to-end encoding.
* The independent wide-integer transform is spot-checked against a direct sign-matrix transform.
* Source variants and sanitizer modes receive matching input counts and fingerprints within each group.
* Elapsed harness time includes input generation, the reference calculation and result checking.
* Sanitized numeric mismatches come from the reference comparison, not sanitizer diagnostics.

svt-highbd-first-compound-predictor
-----------------------------------

Status: validated
Classification: historical_replay
Evidence: cases/svt/result.json

Checks with a reported difference: 1
Checks with an execution or expectation error: 0
* before: svt-first-predictor-dst; 52488 predictor pairs

Limits:
* This is a retrospective replay of one known production regression, not a prospective discovery.
* The C implementation is a differential reference; it is not an independent arithmetic proof.
* Sentinel checks detect unintended writes and persistent-state changes. They do not detect reads from uninitialized storage.
* These are direct primitive calls. No bitstream corruption, production-call frequency, or encoder speed claim follows.
* The non-compound baseline and compound pairs perform different work; their pass/fail results are not an equal-budget comparison.

aom-highbd-intrabc-dispatch
---------------------------

Status: validated
Classification: historical_replay
Evidence: cases/aom/result.json

Checks with a reported difference: 1
Checks with an execution or expectation error: 0
* before-neon: aom-intrabc-before-route; 0 NEON kernel calls

Limits:
* Historical case selected after the original issue and fix were known; this is not a prospective discovery.
* Complete facade and kernel function bodies are extracted from fixed Git revisions and rebuilt in this run. Other codec paths are fail-fast stubs.
* The rebuild uses recorded upstream headers and a minimal configuration for these extracted functions, not a complete upstream library build.
* The local harness explicitly installs NEON or C dispatch pointers; it does not execute CPU feature detection, the generated RTCD initializer, an encoder, or a decoder.
* The two-tap non-compound unscaled IntraBC contract covers phases (8,0), (0,8), and (8,8), with uint16 storage at 8/10/12 bits. The copy path is outside this case.
* Source allocations include legal vector padding. Guard checks detect output changes outside the requested block, not every permissible source read.
* No local facade result establishes full-codec coverage, real-world issue prevalence, or whole-codec speedup.

Interpretation
--------------

Harness elapsed time includes generation, reference calculations and checking.
It is not encoder throughput. A local facade check does not establish production
CPU detection or end-to-end coverage. No discovery rate or acceptance probability
is estimated. See each case's limitations and original command logs.
