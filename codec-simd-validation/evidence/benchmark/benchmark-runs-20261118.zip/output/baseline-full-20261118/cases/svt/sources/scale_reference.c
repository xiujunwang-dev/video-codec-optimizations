/*
* Copyright(c) 2019 Intel Corporation
* Copyright (c) 2016, Alliance for Open Media. All rights reserved
*
* This source code is subject to the terms of the BSD 3-Clause Clear License and
* the Alliance for Open Media Patent License 1.0. If the BSD 3-Clause Clear License
* was not distributed with this source code in the LICENSE file, you can
* obtain it at https://www.aomedia.org/license. If the Alliance for Open
* Media Patent License 1.0 was not distributed with this source code in the
* PATENTS file, you can obtain it at https://www.aomedia.org/license/patent-license.
*/



#include "convolve.h"


DECLARE_ALIGNED(256, const InterpKernel, sub_pel_filters_8[SUBPEL_SHIFTS]) = {{0, 0, 0, 128, 0, 0, 0, 0},
                                                                              {0, 2, -6, 126, 8, -2, 0, 0},
                                                                              {0, 2, -10, 122, 18, -4, 0, 0},
                                                                              {0, 2, -12, 116, 28, -8, 2, 0},
                                                                              {0, 2, -14, 110, 38, -10, 2, 0},
                                                                              {0, 2, -14, 102, 48, -12, 2, 0},
                                                                              {0, 2, -16, 94, 58, -12, 2, 0},
                                                                              {0, 2, -14, 84, 66, -12, 2, 0},
                                                                              {0, 2, -14, 76, 76, -14, 2, 0},
                                                                              {0, 2, -12, 66, 84, -14, 2, 0},
                                                                              {0, 2, -12, 58, 94, -16, 2, 0},
                                                                              {0, 2, -12, 48, 102, -14, 2, 0},
                                                                              {0, 2, -10, 38, 110, -14, 2, 0},
                                                                              {0, 2, -8, 28, 116, -12, 2, 0},
                                                                              {0, 0, -4, 18, 122, -10, 2, 0},
                                                                              {0, 0, -2, 8, 126, -6, 2, 0}};

DECLARE_ALIGNED(256, const InterpKernel, sub_pel_filters_4[SUBPEL_SHIFTS]) = {{0, 0, 0, 128, 0, 0, 0, 0},
                                                                              {0, 0, -4, 126, 8, -2, 0, 0},
                                                                              {0, 0, -8, 122, 18, -4, 0, 0},
                                                                              {0, 0, -10, 116, 28, -6, 0, 0},
                                                                              {0, 0, -12, 110, 38, -8, 0, 0},
                                                                              {0, 0, -12, 102, 48, -10, 0, 0},
                                                                              {0, 0, -14, 94, 58, -10, 0, 0},
                                                                              {0, 0, -12, 84, 66, -10, 0, 0},
                                                                              {0, 0, -12, 76, 76, -12, 0, 0},
                                                                              {0, 0, -10, 66, 84, -12, 0, 0},
                                                                              {0, 0, -10, 58, 94, -14, 0, 0},
                                                                              {0, 0, -10, 48, 102, -12, 0, 0},
                                                                              {0, 0, -8, 38, 110, -12, 0, 0},
                                                                              {0, 0, -6, 28, 116, -10, 0, 0},
                                                                              {0, 0, -4, 18, 122, -8, 0, 0},
                                                                              {0, 0, -2, 8, 126, -4, 0, 0}};

DECLARE_ALIGNED(256, const InterpKernel, sub_pel_filters_8sharp[SUBPEL_SHIFTS]) = {{0, 0, 0, 128, 0, 0, 0, 0},
                                                                                   {-2, 2, -6, 126, 8, -2, 2, 0},
                                                                                   {-2, 6, -12, 124, 16, -6, 4, -2},
                                                                                   {-2, 8, -18, 120, 26, -10, 6, -2},
                                                                                   {-4, 10, -22, 116, 38, -14, 6, -2},
                                                                                   {-4, 10, -22, 108, 48, -18, 8, -2},
                                                                                   {-4, 10, -24, 100, 60, -20, 8, -2},
                                                                                   {-4, 10, -24, 90, 70, -22, 10, -2},
                                                                                   {-4, 12, -24, 80, 80, -24, 12, -4},
                                                                                   {-2, 10, -22, 70, 90, -24, 10, -4},
                                                                                   {-2, 8, -20, 60, 100, -24, 10, -4},
                                                                                   {-2, 8, -18, 48, 108, -22, 10, -4},
                                                                                   {-2, 6, -14, 38, 116, -22, 10, -4},
                                                                                   {-2, 6, -10, 26, 120, -18, 8, -2},
                                                                                   {-2, 4, -6, 16, 124, -12, 6, -2},
                                                                                   {0, 2, -2, 8, 126, -6, 2, -2}};

DECLARE_ALIGNED(256, const InterpKernel, sub_pel_filters_8smooth[SUBPEL_SHIFTS]) = {{0, 0, 0, 128, 0, 0, 0, 0},
                                                                                    {0, 2, 28, 62, 34, 2, 0, 0},
                                                                                    {0, 0, 26, 62, 36, 4, 0, 0},
                                                                                    {0, 0, 22, 62, 40, 4, 0, 0},
                                                                                    {0, 0, 20, 60, 42, 6, 0, 0},
                                                                                    {0, 0, 18, 58, 44, 8, 0, 0},
                                                                                    {0, 0, 16, 56, 46, 10, 0, 0},
                                                                                    {0, -2, 16, 54, 48, 12, 0, 0},
                                                                                    {0, -2, 14, 52, 52, 14, -2, 0},
                                                                                    {0, 0, 12, 48, 54, 16, -2, 0},
                                                                                    {0, 0, 10, 46, 56, 16, 0, 0},
                                                                                    {0, 0, 8, 44, 58, 18, 0, 0},
                                                                                    {0, 0, 6, 42, 60, 20, 0, 0},
                                                                                    {0, 0, 4, 40, 62, 22, 0, 0},
                                                                                    {0, 0, 4, 36, 62, 26, 0, 0},
                                                                                    {0, 0, 2, 34, 62, 28, 2, 0}};

DECLARE_ALIGNED(256, const InterpKernel, bilinear_filters[SUBPEL_SHIFTS])        = {{0, 0, 0, 128, 0, 0, 0, 0},
                                                                                    {0, 0, 0, 120, 8, 0, 0, 0},
                                                                                    {0, 0, 0, 112, 16, 0, 0, 0},
                                                                                    {0, 0, 0, 104, 24, 0, 0, 0},
                                                                                    {0, 0, 0, 96, 32, 0, 0, 0},
                                                                                    {0, 0, 0, 88, 40, 0, 0, 0},
                                                                                    {0, 0, 0, 80, 48, 0, 0, 0},
                                                                                    {0, 0, 0, 72, 56, 0, 0, 0},
                                                                                    {0, 0, 0, 64, 64, 0, 0, 0},
                                                                                    {0, 0, 0, 56, 72, 0, 0, 0},
                                                                                    {0, 0, 0, 48, 80, 0, 0, 0},
                                                                                    {0, 0, 0, 40, 88, 0, 0, 0},
                                                                                    {0, 0, 0, 32, 96, 0, 0, 0},
                                                                                    {0, 0, 0, 24, 104, 0, 0, 0},
                                                                                    {0, 0, 0, 16, 112, 0, 0, 0},
                                                                                    {0, 0, 0, 8, 120, 0, 0, 0}};

DECLARE_ALIGNED(256, const InterpKernel, sub_pel_filters_4smooth[SUBPEL_SHIFTS]) = {{0, 0, 0, 128, 0, 0, 0, 0},
                                                                                    {0, 0, 30, 62, 34, 2, 0, 0},
                                                                                    {0, 0, 26, 62, 36, 4, 0, 0},
                                                                                    {0, 0, 22, 62, 40, 4, 0, 0},
                                                                                    {0, 0, 20, 60, 42, 6, 0, 0},
                                                                                    {0, 0, 18, 58, 44, 8, 0, 0},
                                                                                    {0, 0, 16, 56, 46, 10, 0, 0},
                                                                                    {0, 0, 14, 54, 48, 12, 0, 0},
                                                                                    {0, 0, 12, 52, 52, 12, 0, 0},
                                                                                    {0, 0, 12, 48, 54, 14, 0, 0},
                                                                                    {0, 0, 10, 46, 56, 16, 0, 0},
                                                                                    {0, 0, 8, 44, 58, 18, 0, 0},
                                                                                    {0, 0, 6, 42, 60, 20, 0, 0},
                                                                                    {0, 0, 4, 40, 62, 22, 0, 0},
                                                                                    {0, 0, 4, 36, 62, 26, 0, 0},
                                                                                    {0, 0, 2, 34, 62, 30, 0, 0}};

void svt_av1_highbd_convolve_2d_scale_c(const uint16_t* src, int src_stride, uint16_t* dst, int dst_stride, int w,
                                        int h, const InterpFilterParams* filter_params_x,
                                        const InterpFilterParams* filter_params_y, const int subpel_x_qn,
                                        const int x_step_qn, const int subpel_y_qn, const int y_step_qn,
                                        ConvolveParams* conv_params, int bd) {
    int16_t        im_block[(2 * MAX_SB_SIZE + MAX_FILTER_TAP) * MAX_SB_SIZE];
    int            im_h         = (((h - 1) * y_step_qn + subpel_y_qn) >> SCALE_SUBPEL_BITS) + filter_params_y->taps;
    int            im_stride    = w;
    const int      fo_vert      = filter_params_y->taps / 2 - 1;
    const int      fo_horiz     = filter_params_x->taps / 2 - 1;
    CONV_BUF_TYPE* dst16        = conv_params->dst;
    const int      dst16_stride = conv_params->dst_stride;
    const int      bits         = FILTER_BITS * 2 - conv_params->round_0 - conv_params->round_1;
    assert(bits >= 0);
    // horizontal filter
    const uint16_t* src_horiz = src - fo_vert * src_stride;
    for (int y = 0; y < im_h; ++y) {
        int x_qn = subpel_x_qn;
        for (int x = 0; x < w; ++x, x_qn += x_step_qn) {
            const uint16_t* const src_x        = &src_horiz[(x_qn >> SCALE_SUBPEL_BITS)];
            const int             x_filter_idx = (x_qn & SCALE_SUBPEL_MASK) >> SCALE_EXTRA_BITS;
            assert(x_filter_idx < SUBPEL_SHIFTS);
            const int16_t* x_filter = av1_get_interp_filter_subpel_kernel(*filter_params_x, x_filter_idx);
            int32_t        sum      = (1 << (bd + FILTER_BITS - 1));
            for (int k = 0; k < filter_params_x->taps; ++k) {
                sum += x_filter[k] * src_x[k - fo_horiz];
            }
            assert(0 <= sum && sum < (1 << (bd + FILTER_BITS + 1)));
            im_block[y * im_stride + x] = (int16_t)ROUND_POWER_OF_TWO(sum, conv_params->round_0);
        }
        src_horiz += src_stride;
    }

    // vertical filter
    int16_t*  src_vert    = im_block + fo_vert * im_stride;
    const int offset_bits = bd + 2 * FILTER_BITS - conv_params->round_0;
    for (int x = 0; x < w; ++x) {
        int y_qn = subpel_y_qn;
        for (int y = 0; y < h; ++y, y_qn += y_step_qn) {
            const int16_t* src_y        = &src_vert[(y_qn >> SCALE_SUBPEL_BITS) * im_stride];
            const int      y_filter_idx = (y_qn & SCALE_SUBPEL_MASK) >> SCALE_EXTRA_BITS;
            assert(y_filter_idx < SUBPEL_SHIFTS);
            const int16_t* y_filter = av1_get_interp_filter_subpel_kernel(*filter_params_y, y_filter_idx);
            int32_t        sum      = 1 << offset_bits;
            for (int k = 0; k < filter_params_y->taps; ++k) {
                sum += y_filter[k] * src_y[(k - fo_vert) * im_stride];
            }
            assert(0 <= sum && sum < (1 << (offset_bits + 2)));
            CONV_BUF_TYPE res = ROUND_POWER_OF_TWO(sum, conv_params->round_1);
            if (conv_params->is_compound) {
                if (conv_params->do_average) {
                    int32_t tmp = dst16[y * dst16_stride + x];
                    if (conv_params->use_dist_wtd_comp_avg) {
                        tmp = tmp * conv_params->fwd_offset + res * conv_params->bck_offset;
                        tmp = tmp >> DIST_PRECISION_BITS;
                    } else {
                        tmp += res;
                        tmp = tmp >> 1;
                    }
                    /* Subtract round offset and convolve round */
                    tmp = tmp -
                        ((1 << (offset_bits - conv_params->round_1)) + (1 << (offset_bits - conv_params->round_1 - 1)));
                    dst[y * dst_stride + x] = clip_pixel_highbd(ROUND_POWER_OF_TWO(tmp, bits), bd);
                } else {
                    dst16[y * dst16_stride + x] = res;
                }
            } else {
                /* Subtract round offset and convolve round */
                int32_t tmp = res -
                    ((1 << (offset_bits - conv_params->round_1)) + (1 << (offset_bits - conv_params->round_1 - 1)));
                dst[y * dst_stride + x] = clip_pixel_highbd(ROUND_POWER_OF_TWO(tmp, bits), bd);
            }
        }
        src_vert++;
    }
}
